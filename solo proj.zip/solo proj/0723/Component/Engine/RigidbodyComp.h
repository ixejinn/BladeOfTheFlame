#pragma once
#include "../../ComponentManager/EngineComp.h"
#include "AEVec2.h"
class RigidbodyComp : public EngineComp
{
	float drag = 0.5f;
	AEVec2 Velocity;
	AEVec2 MaxVelocity;
	bool CheckEpsilon(float v, float Ep = EPSILON);
	
public:
	RigidbodyComp(GO* owner);

	//void Addvelocity(const AEVec2& otherVec);
	void AddVelocity(float x, float y);

	AEVec2 getVelocity();

	void SetVeolcity(AEVec2 vel);

	void ClearVelocity();

	void Update() override;
	void LoadFromJson(const json&) override {};
	json SaveToJson() override { return NULL; }

	static BaseRTTI* CreateRigidbodyComp();
	static constexpr const char* RigidbodyName = "RigidbodyComp";
};