#include "audioComp.h"
#include "AEEngine.h"
#include "AEAudio.h"
#include "../../ComponentManager/Manager.h"
#include "../../GameObjectManager/GameObjectManager.h"
#include "../../Event/Collision.h"


AudioComp::AudioComp(GO* owner) : EngineComp(owner)
{
	mGroup = AEAudioCreateGroup();
	pop = AEAudioLoadSound("");
	bgm = AEAudioLoadSound("");
	volume = 0.5f;
	pitch = 1;

	loop = false;
	Playing = false;
}

AudioComp::~AudioComp()
{
	//Manager<AudioComp>::getptr()->RemovePtr(this);
	Manager::getManagerInstance()->DeleteEngineComp(this);
	AEAudioUnloadAudio(bgm);
	AEAudioUnloadAudio(pop);
	AEAudioUnloadAudioGroup(mGroup);
}

void AudioComp::Update()
{
	//Do NOT Copy this
	if (!Playing)
	{
		Play(bgm);
	}

	//�浹�� pop
}

void AudioComp::SetAudio(std::string s, AEAudio a)
{
	a = AEAudioLoadMusic(s.c_str());
}

void AudioComp::Play(AEAudio a)
{
	int loops = loop ? -1 : 0;
	AEAudioPlay(a, mGroup, volume, pitch, loops);
	Playing = true;
}

bool AudioComp::IsPlaying() const
{
	return Playing;
}

BaseRTTI* AudioComp::CreateAudioComp()
{
	AudioComp* p = new AudioComp(GOManager::getPtr()->getLastObj());
	GOManager::getPtr()->getLastObj()->addComp(p);
	return p;
}
