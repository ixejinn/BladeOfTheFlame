#pragma once
#include "../../ComponentManager/EngineComp.h"
#include <string>
#include "AEAudio.h"

class AudioComp : public EngineComp
{
	AEAudioGroup mGroup;
	AEAudio pop, bgm;
	float volume = 0.5f;
	float pitch = 1;

	bool loop = false;
	bool Playing = false;
public:
	void LoadFromJson(const json&) override {};
	json SaveToJson() override { return NULL; }

	AudioComp(GO* owner);
	~AudioComp();
	void Update() override;
	void SetAudio(std::string s, AEAudio a);
	void Play(AEAudio a);
	bool IsPlaying() const;

	
	static BaseRTTI* CreateAudioComp();

	static constexpr const char* AudioTypeName = "AudioComp";
};