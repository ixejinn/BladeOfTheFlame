#include "particleComp.h"
#include "../Engine/transformComp.h"
#include "../Engine/RigidbodyComp.h"
#include "../Graphics/spriteComp.h"
#include "../../GameObjectManager/GameObjectManager.h"
#include <random>

ParticleComp::ParticleComp(GO* owner)
    : EngineComp(owner)
{
    owner->checkComp<TransformComp>()->SetScale(initialScale);
    owner->checkComp<RigidbodyComp>()->SetVeolcity(initialVelocity);
    if (owner->checkComp<RigidbodyComp>()->getVelocity().y >= 0)
    {
        owner->checkComp<RigidbodyComp>()->AddVelocity((rand() % 9 - 4) * 10, -particleLifetime);
    }
    else
    {
        owner->checkComp<RigidbodyComp>()->AddVelocity((rand() % 9 - 4) * 10, particleLifetime);
    }


    delay = rand() % 1000;
}

void ParticleComp::Update()
{
    float dt = AEFrameRateControllerGetFrameRate();
    delay -= dt;
    if(delay < 0)
    {
    particleLifetime -= dt;
    if(mOwner->checkComp<RigidbodyComp>()->getVelocity().y >= 0)
    {
        mOwner->checkComp<RigidbodyComp>()->AddVelocity((rand() % 9 - 4) * 10, -dt * 10 / particleLifetime);
    }
    else
    {
        mOwner->checkComp<RigidbodyComp>()->AddVelocity((rand() % 9 - 4) * 10, +dt * 10 / particleLifetime);
    }

    mOwner->checkComp<SpriteComp>()->SetColor(mOwner->checkComp<SpriteComp>()->Getcolor().r -= dt* particleLifetime,
        mOwner->checkComp<SpriteComp>()->Getcolor().g -= dt* particleLifetime,
        mOwner->checkComp<SpriteComp>()->Getcolor().b -= dt* particleLifetime);
    if (particleLifetime < 0)
    {
        mOwner->checkComp<RigidbodyComp>()->AddVelocity((rand() % 9 - 4) * 10, 0);
        mOwner->checkComp<SpriteComp>()->SetColor(255, 255, 255);
        mOwner->checkComp<RigidbodyComp>()->SetVeolcity(initialVelocity);
        mOwner->checkComp<TransformComp>()->SetScale(initialScale);
        delay = rand() % 50 ;
        if (mOwner->checkComp<RigidbodyComp>()->getVelocity().y >= 0)
        {
            mOwner->checkComp<RigidbodyComp>()->AddVelocity((rand() % 9 - 4) * 10, -particleLifetime);
        }
        else
        {
            mOwner->checkComp<RigidbodyComp>()->AddVelocity((rand() % 9 - 4) * 10, particleLifetime);
        }
    }
    }
}

void ParticleComp::SetInitialVelocity(const AEVec2& vel) { initialVelocity = vel; }
void ParticleComp::SetInitialScale(const AEVec2& scale) { initialScale = scale; }
void ParticleComp::SetParticleLifetime(float lifetime) { particleLifetime = lifetime; }

BaseRTTI* ParticleComp::CreateParticleComp()
{
    ParticleComp* p = new ParticleComp(GOManager::getPtr()->getLastObj());
    GOManager::getPtr()->getLastObj()->addComp(p);
    return p;
}