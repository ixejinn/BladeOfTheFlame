#pragma once
#include "../../ComponentManager/EngineComp.h"
#include "../Engine/RigidbodyComp.h"
#include "AEEngine.h"
#include <cmath>
#include <vector>

class ParticleComp : public EngineComp
{
private:
    AEVec2 initialVelocity = {0, 0};
    AEVec2 initialScale = { 10, 10 };
    float particleLifetime = 1000;
    float delay;
public:
    ParticleComp(GO* owner);

    void Update() override;
    
    float GetLifetime() { return particleLifetime; }
    AEVec2 GetInitialVeolcity() { return initialVelocity; }
    void SetInitialVelocity(const AEVec2& vel);
    void SetInitialScale(const AEVec2& scale);
    void SetParticleLifetime(float lifetime);

    // JSON serialization methods
    void LoadFromJson(const json&) override {};
    json SaveToJson() override { return NULL; }

    static BaseRTTI* CreateParticleComp();
    static constexpr const char* ParticleCompTypeName = "ParticleComp";
};