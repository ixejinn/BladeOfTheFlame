#include "transformComp.h"
#include "../../GameObjectManager/GameObjectManager.h"
#include "../Graphics/spriteComp.h"
#include <iostream>

void TransformComp::CalculateMatrix()
{
	//create a transform matrix
	AEMtx33 translateMtx = { 0 };
	AEMtx33Trans(&translateMtx, pos.x, pos.y);
	// create a rotation matrix
	AEMtx33 rotationMtx{ 0 };
	AEMtx33Rot(&rotationMtx, rot);
	// create a scale matrix
	AEMtx33 scaleMtx = { 0 };
	AEMtx33Scale(&scaleMtx, scale.x, scale.y);
	//concatenate them
	AEMtx33Concat(&transformMatrix, &rotationMtx, &scaleMtx);
	AEMtx33Concat(&transformMatrix, &translateMtx, &transformMatrix);
}

TransformComp::TransformComp(GO* owner) : EngineComp(owner), pos(), scale(), rot(0), transformMatrix()
{
	pos.x = 0;
	pos.y = 0;
	scale.x = 25.f;
	scale.y = 125.f;

	CalculateMatrix();
}

void TransformComp::Update()
{
	CalculateMatrix();
}

void TransformComp::SetPos(const AEVec2& otherPos)
{
	this->pos = otherPos;

	CalculateMatrix();
}

void TransformComp::SetScale(const AEVec2& otherScale)
{
	this->scale = otherScale;

	CalculateMatrix();
}

void TransformComp::SetRot(const float& otherRot)
{
	this->rot = otherRot;

	CalculateMatrix();
}

void TransformComp::PrintMatrix()
{
	std::cout << "Printing Transform Comp. With this values: " << std::endl;
	std::cout << "Translate : " << pos.x << " " << pos.y;
	std::cout << "Rotation  : " << rot;
	std::cout << "Scale     : " << scale.x << " " << scale.y;
	for (int i = 0; i < 3; i++)
	{
		std::cout << " | ";
		for (int x = 0; x < 3; x++)
		{
			std::cout << " " << transformMatrix.m[i][x];
		}
		std::cout << " |";
		std::cout << std::endl;
	}
}

BaseRTTI* TransformComp::CreateTransformComp()
{
	TransformComp* p = new TransformComp(GOManager::getPtr()->getLastObj());
	GOManager::getPtr()->getLastObj()->addComp(p);
	return p;
}

void TransformComp::LoadFromJson(const json& data)
{
	//Check how you saved, load from there
	auto compData = data.find("CompData");
	if (compData != data.end())
	{
		auto p = compData->find("Pos");

		pos.x = p->begin().value();
		pos.y = (p->begin()+1).value();

		auto s = compData->find("Sca");

		scale.x = s->begin().value();
		scale.y = (s->begin() + 1).value();

		auto r = compData->find("Rot");

		rot = r.value();
	}

	//Data is loded

	//Utilize the data
	CalculateMatrix();
}

json TransformComp::SaveToJson()
{
	json data;
	data["Type"] = TransformTypeName;
	//Save my data
	json compData;
		//pos
	compData["Pos"] = { pos.x, pos.y };
		//sca
	compData["Sca"] = { scale.x, scale.y };
		//rot
	compData["Rot"] = { rot };
	
	data["CompData"] = compData;
	return data;
}
