#include "AnimationComp.h"
#include "../../GameObjectManager/GameObjectManager.h"
#include "../Graphics/spriteComp.h"
#include <algorithm>

AnimationComp::AnimationComp(GO* owner) : GraphicsComp(owner)
{
	AddAnimation("Idle");
	AddAnimation("walk");
	AddAnimation("Attack");
	AddAnimation("Hit");
	AddAnimation("Dead");
	currentAnime = "Idle";
	owner->checkComp<SpriteComp>()->SetRenderMode(texture);
}

AnimationComp::~AnimationComp()
{
	for (auto& it : anime)
	{
		delete it.second;
	}
	anime.clear();
}

void AnimationComp::Update()
{
	float dt = AEFrameRateControllerGetFrameRate();
	auto it = anime.find(currentAnime);
	mOwner->checkComp<SpriteComp>()->SetTexture(it->second->GetDetail());
	elapsedTime += dt;
	if (elapsedTime >= animationTerm)
	{
		elapsedTime = 0;
		anime.find(currentAnime)->second->p++;
	}
}

void AnimationComp::AddAnimation(std::string other)
{
	Animation* p = new Animation;
	anime.emplace(other, p);
}

void AnimationComp::DeleteAnimation(std::string other)
{
	auto it = anime.find(other);
	if (it != anime.end()) {
		delete it->second;
		anime.erase(it);
	}
}

bool AnimationComp::CurrentAnimationOver()
{
	if (anime.find(currentAnime)->second->animationplay != false)
	{
		return true;
	}
	else
		return false;
}


BaseRTTI* AnimationComp::CreateAnimationComp()
{
	AnimationComp* p = new AnimationComp(GOManager::getPtr()->getLastObj());
	GOManager::getPtr()->getLastObj()->addComp(p);
	return p;
}

Animation::Animation()
{
	detail.clear();
	animationplay = false;
}

Animation::~Animation()
{
	detail.clear();
}

std::string Animation::GetDetail()
{
	animationplay = false;
	if (detail.size() < p + 1)
	{
		p = 0;
		animationplay = true;
	}
	return detail[p];
}

void AnimationComp::AddDetail(std::string s, std::string which)
{
	anime.find(which)->second->detail.push_back(s);
}

void AnimationComp::DeleteDetail(std::string s, std::string which)
{
	auto newEnd = std::remove(anime.find(which)->second->detail.begin(), anime.find(which)->second->detail.end(), s);
	anime.find(which)->second->detail.erase(newEnd, anime.find(which)->second->detail.end());
}
