#pragma once
#include "../../ComponentManager/GraphicsComp.h"
#include "AEEngine.h"
#include <vector>
#include <map>
#include <string>

class Animation
{
public:
	Animation();
	~Animation();
	int currentFrame = 0;
	int p = 0;

	std::vector<std::string> detail;

	std::string GetDetail();
	bool animationplay;

};

class AnimationComp : public GraphicsComp
{
private:
	std::string currentAnime;
	std::map<std::string, Animation*> anime;
	float animationTerm = 1000;
	float elapsedTime = 0;
public:
	AnimationComp(GO* owner);
	~AnimationComp();
	void Update() override;

	void AddAnimation(std::string);
	void DeleteAnimation(std::string);
	bool CurrentAnimationOver();
	void AddDetail(std::string s, std::string which);
	void DeleteDetail(std::string s, std::string which);

	void SetTerm(float other) { animationTerm = other; }
	void ChangeAnimation(std::string s) {	currentAnime = s;	};

	static constexpr const char* AnimationTypeName = "AnimationTypeName";
	static BaseRTTI* CreateAnimationComp();

	void LoadFromJson(const json&) override {};
	json SaveToJson() override { return NULL; }
};