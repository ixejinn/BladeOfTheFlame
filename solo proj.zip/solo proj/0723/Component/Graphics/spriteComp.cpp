#include "SpriteComp.h"
#include "AEEngine.h"
#include "../Engine/transformComp.h"
#include "../../ComponentManager/GameObject.h"
#include "../../GameObjectManager/GameObjectManager.h"

SpriteComp::SpriteComp(GO* owner)
	: GraphicsComp(owner), mTex(nullptr)
{
	mColor = { 255, 255, 255 };
}
SpriteComp::~SpriteComp()
{
	if (mTex)
	{
		AEGfxTextureUnload(mTex);
	}
}

void SpriteComp::SetTexture(const std::string& filepath)
{
	if (mTex != nullptr)
		AEGfxTextureUnload(mTex);

	mTex = AEGfxTextureLoad(filepath.c_str());
}

void SpriteComp::SetColor(unsigned char r, unsigned char g, unsigned char b)
{
	mColor.r = r, mColor.g = g, mColor.b = b;
}

uint8_t floatToByte(float value) {
	// Ŭ����(clamping)�Ͽ� 0���� 255 ���̷� ����
	if (value < 0.0f) value = 0.0f;
	if (value > 255.0f) value = 255.0f;
	return static_cast<uint8_t>(std::round(value));
}

// RGB float ���� 0xAARRGGBB �������� ��ȯ�Ͽ� ��ȯ�ϴ� �Լ�
uint32_t rgbFloatToHex(float r, float g, float b) {
	// RGB float ���� 0���� 255 ������ ������ ��ȯ
	uint8_t red = floatToByte(r);
	uint8_t green = floatToByte(g);
	uint8_t blue = floatToByte(b);

	// ���� ���� 0xFF�� �����Ͽ� ���� �������ϰ� ��
	return (0xFF << 24) | (red << 16) | (green << 8) | blue;
}

void SpriteComp::Update()
{
	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, rgbFloatToHex(mColor.r, mColor.g, mColor.b), 0.0f, 1.0f,  // bottom-left: red
		0.5f, -0.5f, rgbFloatToHex(mColor.r, mColor.g, mColor.b), 1.0f, 1.0f,   // bottom-right: green
		-0.5f, 0.5f, rgbFloatToHex(mColor.r, mColor.g, mColor.b), 0.0f, 0.0f);  // top-left: blue

	AEGfxTriAdd(
		0.5f, -0.5f, rgbFloatToHex(mColor.r, mColor.g, mColor.b), 1.0f, 1.0f,   // bottom-right: green
		0.5f, 0.5f, rgbFloatToHex(mColor.r, mColor.g, mColor.b), 1.0f, 0.0f,    // top-right: white
		-0.5f, 0.5f, rgbFloatToHex(mColor.r, mColor.g, mColor.b), 0.0f, 0.0f);  // top-left: blue
	AEGfxVertexList* mesh = AEGfxMeshEnd();

	if (RenderMode == color)
		AEGfxSetRenderMode(AE_GFX_RM_COLOR);
	else
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);

	AEGfxSetColorToMultiply(1, 1, 1, 1);
	AEGfxSetBlendMode(AE_GFX_BM_BLEND);
	AEGfxSetTransparency(1);
	
	if(RenderMode == texture)
	{
		if (mTex)
		{
			AEGfxTextureSet(mTex, 0, 0);
		}
	}

	TransformComp* transform = mOwner->checkComp<TransformComp>();

	if (transform)
	{
		//modify
		AEMtx33 matrix = transform->GetMatrix();
		AEGfxSetTransform(matrix.m);
	}

	AEGfxMeshDraw(mesh, AE_GFX_MDM_TRIANGLES);
	AEGfxMeshFree(mesh);
}


BaseRTTI* SpriteComp::CreateSpriteComp()
{
	SpriteComp* p = new SpriteComp(GOManager::getPtr()->getLastObj());
	GOManager::getPtr()->getLastObj()->addComp(p);
	return p;
}
