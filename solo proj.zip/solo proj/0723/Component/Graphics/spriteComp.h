#pragma once
#include "../../ComponentManager/Manager.h"
#include "../../ComponentManager/GraphicsComp.h"
#include "AEEngine.h"
#include "AEMath.h"
enum mRander
{
	color,
	texture 
};
class SpriteComp : public GraphicsComp
{
public:
	struct Color
	{
		unsigned char r = 255;
		unsigned char g = 255;
		unsigned char b = 255;
	};
private:
	Color mColor;
	//texture
	AEGfxTexture* mTex;
	//Render mode?
	int RenderMode;
	//Blend mode?
	//Transparency

public:
	SpriteComp(GO* owner);
	~SpriteComp();
	void Update() override;
	//draw
	
	//Gettors/Settors
	Color& Getcolor() { return mColor; };
	void SetTexture(const std::string& filepath);
	void SetColor(unsigned char r, unsigned char g, unsigned char b);
	void SetRenderMode(int a) { RenderMode = a; }

	static constexpr const char* SpriteTypeName = "SpriteComp";
	static BaseRTTI* CreateSpriteComp();

	void LoadFromJson(const json&) override {};
	json SaveToJson() override { return NULL; }
};