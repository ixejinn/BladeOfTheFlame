#include "ScoreComp.h"
#include "../../GameObjectManager/GameObjectManager.h"
#include <sstream>
#include "AEEngine.h"

float ScoreComp::highScore;
float ScoreComp::Consecutive_points1;
float ScoreComp::Consecutive_points2;
bool ScoreComp::renew;

ScoreComp::ScoreComp(GO* owner) : LogicComp(owner)
{
	renew = false;
	myfont = AEGfxCreateFont("Assets/CheeseMatcha.otf", 72);
}

void ScoreComp::LoadFromJson(const json& data)
{
	auto ScoreData = data.find("HighScore");
	highScore = ScoreData->begin().value();
}

json ScoreComp::SaveToJson()
{
	json data;
	data["Type"] = ScoreTypeName;
	json compdata;
	compdata["HighScore"] = { highScore };
	data = compdata;
	return data;
}

void ScoreComp::ShowScore()
{
	std::ostringstream oss;
	oss << "HIGH SCORE : " << highScore;
	std::string str = oss.str();
	const char* cstr1 = str.c_str();
	AEGfxPrint(myfont, cstr1, -1, 0.88, 1, 1.f, 1.f, 1.f, 1.f);
	oss.str("");
	oss << "PLAYER1 SCORE : " << Consecutive_points1;
	str.clear();
	str = oss.str();
	const char* cstr2 = str.c_str();
	AEGfxPrint(myfont, cstr2, -1, -1, 1, 1.f, 1.f, 1.f, 1.f);
	oss.str("");
	oss << "PLAYER2 SCORE : " << Consecutive_points2;
	str.clear();
	str = oss.str();
	const char* cstr3 = str.c_str();
	AEGfxPrint(myfont, cstr3, 0.25, -1, 1, 1.f, 1.f, 1.f, 1.f);
}

void ScoreComp::Update()
{
	if ((highScore < Consecutive_points1 || highScore < Consecutive_points2) && renew == false)
	{
		renew = true;
	}
	if (renew == true)
	{
		AEGfxPrint(myfont, "A new record has been set", 0, 0, 1, 1.f, 1.f, 1.f, 1.f);
	}
	ShowScore();
}

BaseRTTI* ScoreComp::CreateScoreComp()
{
	ScoreComp* p = new ScoreComp(GOManager::getPtr()->getLastObj());
	GOManager::getPtr()->getLastObj()->addComp(p);
	return p;
}