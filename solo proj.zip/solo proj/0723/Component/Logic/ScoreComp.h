#pragma once
#include "../../ComponentManager/LogicComp.h"
#include <string>
#include <AEEngine.h>

class ScoreComp : public  LogicComp
{
private:
	void ShowScore();

	s8 myfont;
public:
	ScoreComp(GO* owner);
	~ScoreComp() { AEGfxDestroyFont(myfont);}

	static float highScore;
	static float Consecutive_points1;
	static float Consecutive_points2;

	void LoadFromJson(const json&) override;
	json SaveToJson() override;
	void Update() override;

	static bool renew;

	//RTTI
	static BaseRTTI* CreateScoreComp();
	static constexpr const char* ScoreTypeName = "ScoreComp";
};