#include "ball.h"
#include "AEEngine.h"
#include "AEInput.h"
#include <algorithm>
#include "../../Component/Engine/transformComp.h"
#include "../../Component/Engine/RigidbodyComp.h"
#include "../../ComponentManager/GameObject.h"
#include "../../GameObjectManager/GameObjectManager.h"
#include "../Logic/playerAComp.h"
#include "../Logic/playerBComp.h"
#include "../../Event/Collision.h"
#include "../Logic/ScoreComp.h"

BallComp::BallComp(GO* owner) : LogicComp(owner)
{
	owner->checkComp<TransformComp>()->SetPos({ 0, 0 });
	owner->checkComp<TransformComp>()->SetScale({ 25, 25 });
}

BallComp::~BallComp()
{
}

void BallComp::Update()
{
	TransformComp* t = mOwner->checkComp<TransformComp>();
	if (!t)
		return;
	RigidbodyComp* r = mOwner->checkComp<RigidbodyComp>();
	if (!t)
		return;

	if (t)
	{
		//ballEnt->posx = t->GetPos().x,
		//	ballEnt->posy = t->GetPos().y;
		if (t->GetPos().y > 450 || t->GetPos().y < -450)
		{
			float tempX, tempY;
			tempX = r->getVelocity().x;
			tempY = -r->getVelocity().y;
			r->SetVeolcity({ tempX, tempY });
		}
		if (t->GetPos().x < -800)
		{
			mOwner->checkComp<ScoreComp>()->Consecutive_points1++;
			t->SetPos({ 0, 0 });
		}
		if (t->GetPos().x > 800)
		{
			mOwner->checkComp<ScoreComp>()->Consecutive_points2++;
			t->SetPos({ 0, 0 });
		}
	}
}

BaseRTTI* BallComp::CreateBallComp()
{
	BallComp* p = new BallComp(GOManager::getPtr()->getLastObj());
	GOManager::getPtr()->getLastObj()->addComp(p);
	return p;
}

void BallComp::changeDir()
{
	TransformComp* t = mOwner->checkComp<TransformComp>();
	if (!t)
		return;
	RigidbodyComp* r = mOwner->checkComp<RigidbodyComp>();
	if (!t)
		return;
	float tempX, tempY;
	tempX = -r->getVelocity().x;
	tempY = r->getVelocity().y;
	r->SetVeolcity({ tempX, tempY });
}

void BallComp::LoadFromJson(const json& data)
{
	auto BallData = data.find("BallVelocity");
	mOwner->checkComp<RigidbodyComp>()->SetVeolcity({ BallData->begin().value(), (BallData->begin() + 1).value() });
}

json BallComp::SaveToJson()
{
	json data;
	data["Type"] = BallTypeName;
	json compData;
	compData["BallVelocity"] = { mOwner->checkComp<RigidbodyComp>()->getVelocity().x,  mOwner->checkComp<RigidbodyComp>()->getVelocity().y };
	data["CompData"] = compData;
	return data;
}
