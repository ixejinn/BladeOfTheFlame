#pragma once
#include "../../ComponentManager/LogicComp.h"
#include "../../EventManager/EventManager.h"

class BallComp : public LogicComp
{
public:
	BallComp(GO* owner);
	~BallComp();
	void Update() override;
	//Entity* ballEnt;
	static constexpr const char* BallTypeName = "BallComp";
	static BaseRTTI* CreateBallComp();
	void changeDir();

	void LoadFromJson(const json&) override;
	json SaveToJson() override;
};