#include "PlayerAComp.h"
#include "AEEngine.h"
#include "AEInput.h"
#include <algorithm>
#include "../../Component/Engine/transformComp.h"
#include "../../Component/Engine/RigidbodyComp.h"
#include "../../ComponentManager/GameObject.h"
#include "../../GameObjectManager/GameObjectManager.h"

PlayerAComp::PlayerAComp(GO* owner)  : LogicComp(owner)
{
	moveSpeed = 20;
	spin = 0;
	owner->checkComp<TransformComp>()->SetPos({ -700, 0 });
}

PlayerAComp::~PlayerAComp()
{
}

void PlayerAComp::Update()
{

	//if (BaseComponent::Update() == false)
	//	return;
	//Check for input

	TransformComp* t = mOwner->checkComp<TransformComp>();
	if (!t)
		return;
	RigidbodyComp* r = mOwner->checkComp<RigidbodyComp>();
	if (!t)
		return;
	
	if (t)
	{
		if (AEInputCheckCurr(AEVK_W))
		{
			if ((t->GetPos().y < 400))
				r->AddVelocity(0, moveSpeed);
			else
			{
				r->ClearVelocity();
			}
		}
		else if (AEInputCheckCurr(AEVK_S))
		{
			if ((t->GetPos().y > -400))
				r->AddVelocity(0, -moveSpeed);
			else
			{
				r->ClearVelocity();
			}
		}
		if ((t->GetPos().y > 400) || (t->GetPos().y < -400))
		{
			float temp = std::min<float>(std::max<float>(t->GetPos().y, -400), 400);
			t->SetPos({ t->GetPos().x, temp });
			r->SetVeolcity({ 0, -(r->getVelocity().y)/10 });
		}
	}

}

BaseRTTI* PlayerAComp::CreatePlayerAComp()
{
	PlayerAComp* p = new PlayerAComp(GOManager::getPtr()->getLastObj());
	GOManager::getPtr()->getLastObj()->addComp(p);
	return p;
}
