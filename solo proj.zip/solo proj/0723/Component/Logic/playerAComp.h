#pragma once
#include "../../ComponentManager/LogicComp.h"

class PlayerAComp : public LogicComp
{
	float moveSpeed;
	float spin;
public:
	PlayerAComp(GO* owner);
	~PlayerAComp();
	void Update() override;

	static constexpr const char* PlayerATypeName = "PlayerAComp";
	static BaseRTTI* CreatePlayerAComp();

	void LoadFromJson(const json&) override {};
	json SaveToJson() override { return NULL; }
};