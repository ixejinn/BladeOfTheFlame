#include "PlayerBComp.h"
#include "AEEngine.h"
#include "AEInput.h"
#include "../../Component/Engine/transformComp.h"
#include "../../Component/Engine/RigidbodyComp.h"
#include "../../ComponentManager/GameObject.h"
#include "../../GameObjectManager/GameObjectManager.h"

PlayerBComp::PlayerBComp(GO* owner) : LogicComp(owner)
{
	moveSpeed = 20;
	spin = 0;
	owner->checkComp<TransformComp>()->SetPos({ 700, 0 });
}

PlayerBComp::~PlayerBComp()
{
}

void PlayerBComp::Update()
{
	TransformComp* t = mOwner->checkComp<TransformComp>();
	if (!t)
		return;
	RigidbodyComp* r = mOwner->checkComp<RigidbodyComp>();
	if (!t)
		return;
	if (t)
	{
		if (AEInputCheckCurr(AEVK_UP))
		{
			if ((t->GetPos().y < 400))
				r->AddVelocity(0, moveSpeed);
			else
			{
				r->ClearVelocity();
			}
		}
		if (AEInputCheckCurr(AEVK_DOWN))
		{
			if ((t->GetPos().y > -400))
				r->AddVelocity(0, -moveSpeed);
			else
			{
				r->ClearVelocity();
			}
		}
		if ((t->GetPos().y > 400) || (t->GetPos().y < -400))
		{
			float temp = std::min<float>(std::max<float>(t->GetPos().y, -400), 400);
			t->SetPos({ t->GetPos().x, temp });
			r->SetVeolcity({ 0, -(r->getVelocity().y) / 10 });
		}
	}
}

BaseRTTI* PlayerBComp::CreatePlayerBComp()
{
	PlayerBComp* p = new PlayerBComp(GOManager::getPtr()->getLastObj());
	GOManager::getPtr()->getLastObj()->addComp(p);
	return p;
}
