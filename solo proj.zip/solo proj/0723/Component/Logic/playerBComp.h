#pragma once
#include "../../ComponentManager/LogicComp.h"

class PlayerBComp : public LogicComp
{
	float moveSpeed;
	float spin;
public:
	PlayerBComp(GO* owner);
	~PlayerBComp();
	void Update() override;

	static constexpr const char* PlayerBTypeName = "PlayerBComp";
	static BaseRTTI* CreatePlayerBComp();

	void LoadFromJson(const json&) override {};
	json SaveToJson() override { return NULL; }
};