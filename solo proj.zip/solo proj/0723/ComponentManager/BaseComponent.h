#pragma once
#include "../RTTI/BaseRTTI.h"
#include "GameObject.h"

class GO;

class BaseComponent : public BaseRTTI
{
	BaseComponent() = delete; 
	BaseComponent(const BaseComponent&) = delete;
protected:
	GO* mOwner;
public:
	virtual void Update() = 0;
	virtual ~BaseComponent() {};
	BaseComponent(GO* owner) : mOwner(owner) {};
};