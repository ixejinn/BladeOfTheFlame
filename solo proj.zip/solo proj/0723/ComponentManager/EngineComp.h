#pragma once
#include "BaseComponent.h"
#include "Manager.h"
#include <map>

class BaseComponent;

class EngineComp : public BaseComponent
{
public:
	EngineComp(GO* Owner) : BaseComponent(Owner)
	{
		Manager::getManagerInstance()->AddEngineComp(this);
	}

	virtual ~EngineComp()
	{
		Manager::getManagerInstance()->DeleteEngineComp(this);
	}

	void Update() override
	{

	}
};
