#include "GameObject.h"
#include <algorithm>
void GO::addComp(BaseComponent* A)
{
	comp.push_back(A);
}


GO::~GO()
{
	//while(comp.begin() != comp.end())
	//while (comp.size() > 0)
	while (comp.empty() == true)
	{
		delete comp.front();
		comp.pop_front();
	}
}

std::list<BaseComponent*> GO::AllComp()
{
	return comp;
}

void GO::deleteComp(BaseComponent* A)
{
	std::list<BaseComponent*>::iterator found = std::find(comp.begin(), comp.end(), A);
	
	if (found == comp.end())
		return;
	else
	{
		comp.remove(*found); //this calls delete A
	}
}
