#pragma once
#include <list>
#include "BaseComponent.h"

class BaseComponent;

class GO
{
private:
	std::list<BaseComponent*> comp;
public:
	GO() {};
	virtual void addComp(BaseComponent* A);
	template <typename T>
	T* checkComp();
	virtual void deleteComp(BaseComponent* A);
	virtual ~GO();
	std::list<BaseComponent*>AllComp();
};
#include "GameObject.inl"