#pragma once
#include "BaseComponent.h"
#include "Manager.h"
#include <map>

class BaseComponent;

class GraphicsComp : public BaseComponent
{
public:
	GraphicsComp(GO* Owner) : BaseComponent(Owner)
	{
		Manager::getManagerInstance()->AddEngineComp(this);
	}

	virtual ~GraphicsComp()
	{
		Manager::getManagerInstance()->DeleteEngineComp(this);
	}

	void Update() override
	{

	}
};