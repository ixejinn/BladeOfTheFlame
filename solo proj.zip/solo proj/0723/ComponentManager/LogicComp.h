#pragma once
#include "BaseComponent.h"
#include "Manager.h"
#include <string>
class BaseComponent;

class LogicComp : public BaseComponent
{
public:
	LogicComp(GO* Owner) : BaseComponent(Owner)
	{
		Manager::getManagerInstance()->AddLogicComp(this);
	}

	virtual ~LogicComp()
	{
		Manager::getManagerInstance()->DeleteLogicComp(this);
	}

	void Update() override
	{

	}

	static constexpr const char* LogicName = "LogicComp";
};