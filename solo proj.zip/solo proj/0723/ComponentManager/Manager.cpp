#include "Manager.h"

Manager* Manager::mInstance = nullptr;