#pragma once
#include <list>
#include "BaseComponent.h"
#include <algorithm>
class Manager
{
private:
    std::list<BaseComponent*> LogicContainer;
    std::list<BaseComponent*> GraphicsContainer;
    std::list<BaseComponent*> EngineContainer;

    static Manager* mInstance;

    Manager() {};
    Manager(const Manager&) = delete;
    Manager& operator=(const Manager&) = delete;
    virtual ~Manager() {};

public:
//AddComp
    void AddLogicComp(BaseComponent* a)
    {
        LogicContainer.push_back(a);
    }
    void AddEngineComp(BaseComponent* a)
    {
        EngineContainer.push_back(a);
    }    
    void AddGraphicsComp(BaseComponent* a)
    {
        GraphicsContainer.push_back(a);
    }
//DeleteComp
    void DeleteLogicComp(BaseComponent* a)
    {
        auto it = std::find(LogicContainer.begin(), LogicContainer.end(), a);
        if (it != LogicContainer.end()) 
        {
            LogicContainer.erase(it);
            delete a;
        }
    }
    void DeleteEngineComp(BaseComponent* a)
    {
        auto it = std::find(EngineContainer.begin(), EngineContainer.end(), a);
        if (it != EngineContainer.end())
        {
            EngineContainer.erase(it);
            delete a;
        }
    }
    void DeleteGraphicsComp(BaseComponent* a)
    {
        auto it = std::find(GraphicsContainer.begin(), GraphicsContainer.end(), a);
        if (it != GraphicsContainer.end())
        {
            GraphicsContainer.erase(it);
            delete a;
        }
    }
//Update
    void UpdateEngine()
    {
        //iterate the list
        for (auto a : EngineContainer)
        {
            //we call to that component Update()
            a->Update();
        }
    }
    void UpdateGraphics()
    {
        //iterate the list
        for (auto a : GraphicsContainer)
        {
            //we call to that component Update()
            a->Update();
        }
    }
    void UpdateLogic()
    {
        //iterate the list
        for (auto a : LogicContainer)
        {
            //we call to that component Update()
            a->Update();
        }
    }

///////////////////////////////////////////////

    static Manager* getManagerInstance() 
    {
        if (mInstance == nullptr)
        {
            mInstance = new Manager;
        }

        return mInstance;
    }

    static void deleteManager()
    {
        delete mInstance;
        mInstance = nullptr;
    }
};