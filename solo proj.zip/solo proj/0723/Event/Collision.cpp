#include "Collision.h"
#include <cmath>

Collision::Collision()
{
    SetName("Collision");
    CollisionCase = NoCollision;
}

// �簢���� �簢���� �浹 ���θ� Ȯ���ϴ� �Լ�
bool Collision::isRectCollision(const Entity& other) {
    return !(owner->posx + owner->width< other.posx ||
        owner->posx > other.posx + other.width ||
        owner->posy + owner->height < other.posy ||
        owner->posy > other.posy + other.height);
}

// �簢���� ���� �浹 ���θ� Ȯ���ϴ� �Լ�
bool Collision::isRectCircleCollision(const Entity& other) {
    float closestX = std::max(owner->posx, std::min(other.posx, owner->posx + owner->width));
    float closestY = std::max(owner->posy, std::min(other.posy, owner->posy + owner->height));
    float distanceX = other.posx - closestX;
    float distanceY = other.posy - closestY;
    return (distanceX * distanceX + distanceY * distanceY) <= (other.radius * other.radius);
}

bool Collision::isCircleRectCollision(const Entity& other)
{
    float closestX = std::max(other.posx, std::min(owner->posx, other.posx + other.width));
    float closestY = std::max(other.posy, std::min(owner->posy, other.posy + other.height));
    float distanceX = owner->posx - closestX;
    float distanceY = owner->posy - closestY;
    return (distanceX * distanceX + distanceY * distanceY) <= (owner->radius * owner->radius);
}

// ���� ���� �浹 ���θ� Ȯ���ϴ� �Լ�
bool Collision::isCircleCollision(const Entity& other) {
    float distanceX = owner->posx - other.posx;
    float distanceY = owner->posy - other.posy;
    float distanceSquared = distanceX * distanceX + distanceY * distanceY;
    float radiusSum = owner->radius + other.radius;
    return distanceSquared <= (radiusSum * radiusSum);
}

void Collision::checkCollision(const Entity& other, int ccase)
{
    //AABB vs AABB
    if (ccase == 1 && isRectCollision(other) == true)
    {
        CollisionCase = AABBvsAABB;
        return;
    }
    else if (ccase == 2 && isCircleRectCollision(other) == true)
    {
        CollisionCase = AABBvsCircle;
        return;
    }
    else if (ccase == 3 && isRectCircleCollision(other) == true)
    {
        CollisionCase = AABBvsCircle;
        return;
    }
    else if (ccase == 4 && isCircleCollision(other) == true)
    {
        CollisionCase = CirclevsCircle;
        return;
    }
    else
    {
        CollisionCase = NoCollision;
        return;
    }
}

