#pragma once
#include "../EventManager/EventManager.h"
#include <string>

class EventManager;

enum collide
{
	NoCollision = 0,
	AABBvsAABB = 1,
	AABBvsCircle = 2,
	CirclevsCircle = 3
};

class Collision : public LocalEvent
{
private:
	bool isRectCollision(const Entity& other);
	bool isRectCircleCollision(const Entity& other);
	bool isCircleRectCollision(const Entity& other);
	bool isCircleCollision(const Entity& other);
public:
	Collision();
	~Collision() {};
	int CollisionCase;
	void checkCollision(const Entity& other, int ccase);
};