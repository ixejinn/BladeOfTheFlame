#include "EventManager.h"

EventManager* EventManager::instance = nullptr;

void EventManager::AddEvent(Event* newEvent)
{
	allEvents.push(newEvent);
}

void EventManager::DispatchAllEvnets()
{
	while (!allEvents.empty())
	{
		auto it = registeredEntities.find(allEvents.front()->name);
		for (Entity* temp : it->second)
		{
			temp->OnEvent(allEvents.front());
		}
		delete allEvents.front();
		allEvents.pop();
	}
}

EventManager::~EventManager()
{
	while (allEvents.size() != 0)
	{
		delete allEvents.front();
		allEvents.pop();
	}
}

EventManager* EventManager::GetEventManagerInstance()
{
	if(instance == NULL) 
	{
		instance = new EventManager();
	}
	return instance;
}

Event::~Event()
{
	if (name.empty())
		return;
	else
	{
		name.clear();
		delete &name;
	}
}

void Event::SetName(std::string eName)
{
	this->name = eName;
}
