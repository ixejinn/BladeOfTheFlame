#pragma once
#include <string>
#include <vector>
struct Event
{
	Event() {};
	virtual ~Event();
	std::string name;
	void SetName(std::string eName);
};

class Entity
{
public:
	virtual void OnEvent(Event* ev) = 0;
	float posx, posy, width, height, radius;
};

struct LocalEvent : public Event
{
	Entity* owner;
};

#include <queue>
#include <map>
class EventManager
{
private:
	//Make singleton
	static EventManager* instance;
	EventManager() {};
	EventManager(const EventManager& other);

	//A container for all my events*
	std::queue<Event*> allEvents;

	//delete undispatched events if any on destructor
	~EventManager();

	//A container to have which entities are registered to which events
	//Map of (events, container of entities*)
	std::map<std::string, std::vector<Entity*>> registeredEntities;

public:
	static EventManager* GetEventManagerInstance();

	//Interface:
	//Add an event (event*) this are pointers to dynamic memory, called as the following: AddEvent(new Event);
	void AddEvent(Event* newEvent);

	//templated fn:
	//		Register entities to a certain event TYPE
	template<typename T>
	void RegisterEntity(Entity* entity);
	//		UnRegister entities to a certain event TYPE
	template<typename T>
	void UnRegisterEntity(Entity* entity);

	//DispatchAllEvents
	void DispatchAllEvnets();
};

#include "RegisterEntity.inl"