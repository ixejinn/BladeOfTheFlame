#include "GoalLevel.h"
#include "GameStateManager.h"
#include "../GameObjectManager/GameObjectManager.h"
#include "../../Component/Logic/ScoreComp.h"
#include "../../Serializer/Serializer.h"
#include "../Component/Engine/transformComp.h"
#include "../Component/Engine/audioComp.h"
#include "../Component/Engine/RigidbodyComp.h"
#include "../Component/Graphics/spriteComp.h"
#include "../Component/Logic/playerAComp.h"
#include "../Component/Logic/playerBComp.h"
#include "../Component/Logic/ScoreComp.h"
#include "../Component/Engine/particleComp.h"
#include "../Component/Logic/ball.h"
#include "../Component/Graphics/AnimationComp.h"
#include "../RTTI/Registry.h"
#include "../Serializer/Serializer.h"
#include "../Event/Collision.h"
#include "ParticleSystem.h"
#include <iostream>


void Levels::GoalLevel::Init()
{
	std::cout << "Goal level INIT:" << std::endl;


	//create GO named "Bar1"
	//Add its components
	bar1 = GOManager::getPtr()->addObj();
	TransformComp* transform1 = static_cast<TransformComp*>(TransformComp::CreateTransformComp());
	SpriteComp* sprite1 = static_cast<SpriteComp*>(SpriteComp::CreateSpriteComp());
	PlayerAComp* player1 = static_cast<PlayerAComp*>(PlayerAComp::CreatePlayerAComp());
	AudioComp* audio1 = static_cast<AudioComp*>(AudioComp::CreateAudioComp());
	RigidbodyComp* rigidbody1 = static_cast<RigidbodyComp*>(RigidbodyComp::CreateRigidbodyComp());
	ScoreComp* score = static_cast<ScoreComp*>(ScoreComp::CreateScoreComp());
	bar1->addComp(transform1);
	bar1->addComp(sprite1);
	bar1->addComp(player1);
	bar1->addComp(audio1);
	bar1->addComp(rigidbody1);
	bar1->addComp(score);
	bar1->checkComp<SpriteComp>()->SetRenderMode(color);

	//create ANOTHER GO named "Bar2"
	//Add its components
	bar2 = GOManager::getPtr()->addObj();
	TransformComp* transform2 = static_cast<TransformComp*>(TransformComp::CreateTransformComp());
	SpriteComp* sprite2 = static_cast<SpriteComp*>(SpriteComp::CreateSpriteComp());
	PlayerBComp* player2 = static_cast<PlayerBComp*>(PlayerBComp::CreatePlayerBComp());
	AudioComp* audio2 = static_cast<AudioComp*>(AudioComp::CreateAudioComp());
	RigidbodyComp* rigidbody2 = static_cast<RigidbodyComp*>(RigidbodyComp::CreateRigidbodyComp());

	bar2->addComp(transform2);
	bar2->addComp(sprite2);
	bar2->addComp(player2);
	bar2->addComp(audio2);
	bar2->addComp(rigidbody2);
	bar2->addComp(score);
	bar2->checkComp<SpriteComp>()->SetRenderMode(color);

	ball = GOManager::getPtr()->addObj();
	TransformComp* transform3 = static_cast<TransformComp*>(TransformComp::CreateTransformComp());
	SpriteComp* sprite3 = static_cast<SpriteComp*>(SpriteComp::CreateSpriteComp());
	BallComp* ballcomp = static_cast<BallComp*>(BallComp::CreateBallComp());
	AudioComp* audio3 = static_cast<AudioComp*>(AudioComp::CreateAudioComp());
	RigidbodyComp* rigidbody3 = static_cast<RigidbodyComp*>(RigidbodyComp::CreateRigidbodyComp());
	AnimationComp* animation = static_cast<AnimationComp*>(AnimationComp::CreateAnimationComp());

	ball->addComp(transform3);
	ball->addComp(sprite3);
	ball->addComp(ballcomp);
	ball->addComp(audio3);
	ball->addComp(rigidbody3);
	ball->addComp(score);
	ball->addComp(animation);
	ball->checkComp<RigidbodyComp>()->SetVeolcity({ 500, 500 });
	ball->checkComp<SpriteComp>()->SetRenderMode(texture);
	ball->checkComp<AnimationComp>()->AddDetail("Assets/abc.png", "Idle");
	ball->checkComp<AnimationComp>()->AddDetail("Assets/PlanetTexture.png", "Idle");

	ParticleSystem::getPtr()->SetParticleCount(20, ball);
	ParticleSystem::getPtr()->SetInitialVelocity({ 1, 1 }, ball);

	//ParticleObject = GOManager::getPtr()->addObj();
	//TransformComp* particletransformcomp= static_cast<TransformComp*>(TransformComp::CreateTransformComp());
	//SpriteComp* particlespritecomp = static_cast<SpriteComp*>(SpriteComp::CreateSpriteComp());
	//AudioComp* particleaudiocomp = static_cast<AudioComp*>(AudioComp::CreateAudioComp());
	//RigidbodyComp* particlerigidbodycomp = static_cast<RigidbodyComp*>(RigidbodyComp::CreateRigidbodyComp());
	//ParticleComp* particle = static_cast<ParticleComp*>(ParticleComp::CreateParticleComp());

	//ParticleObject->addComp(particle);
	//ParticleObject->addComp(particletransformcomp);
	//ParticleObject->addComp(particlespritecomp);
	//ParticleObject->addComp(particleaudiocomp);
	//ParticleObject->addComp(particlerigidbodycomp);

	//ParticleObject2 = GOManager::getPtr()->addObj();
	//TransformComp* particletransformcomp2 = static_cast<TransformComp*>(TransformComp::CreateTransformComp());
	//SpriteComp* particlespritecomp2 = static_cast<SpriteComp*>(SpriteComp::CreateSpriteComp());
	//AudioComp* particleaudiocomp2 = static_cast<AudioComp*>(AudioComp::CreateAudioComp());
	//RigidbodyComp* particlerigidbodycomp2 = static_cast<RigidbodyComp*>(RigidbodyComp::CreateRigidbodyComp());
	//ParticleComp* particle2 = static_cast<ParticleComp*>(ParticleComp::CreateParticleComp());

	//ParticleObject2->addComp(particle2);
	//ParticleObject2->addComp(particletransformcomp2);
	//ParticleObject2->addComp(particlespritecomp2);
	//ParticleObject2->addComp(particleaudiocomp2);
	//ParticleObject2->addComp(particlerigidbodycomp2);

	//ParticleObject3 = GOManager::getPtr()->addObj();
	//TransformComp* particletransformcomp3 = static_cast<TransformComp*>(TransformComp::CreateTransformComp());
	//SpriteComp* particlespritecomp3 = static_cast<SpriteComp*>(SpriteComp::CreateSpriteComp());
	//AudioComp* particleaudiocomp3 = static_cast<AudioComp*>(AudioComp::CreateAudioComp());
	//RigidbodyComp* particlerigidbodycomp3 = static_cast<RigidbodyComp*>(RigidbodyComp::CreateRigidbodyComp());
	//ParticleComp* particle3 = static_cast<ParticleComp*>(ParticleComp::CreateParticleComp());

	//ParticleObject3->addComp(particle3);
	//ParticleObject3->addComp(particletransformcomp3);
	//ParticleObject3->addComp(particlespritecomp3);
	//ParticleObject3->addComp(particleaudiocomp3);
	//ParticleObject3->addComp(particlerigidbodycomp3);

	//////////////
	Serializer::GetPtr()->LoadLevel("../Files/LevelSave.json");
	//////////////
}

void Levels::GoalLevel::Update()
{
	AEGfxSetBackgroundColor(0, 0, 0);
	std::cout << "Goal level UPDATE:" << std::endl;
	float bar1Left = bar1->checkComp<TransformComp>()->GetPos().x - bar1->checkComp<TransformComp>()->GetScale().x / 2;
	float bar1Right = bar1->checkComp<TransformComp>()->GetPos().x + bar1->checkComp<TransformComp>()->GetScale().x / 2;
	float bar1Top = bar1->checkComp<TransformComp>()->GetPos().y + bar1->checkComp<TransformComp>()->GetScale().y / 2;
	float bar1Bottom = bar1->checkComp<TransformComp>()->GetPos().y - bar1->checkComp<TransformComp>()->GetScale().y / 2;

	float bar2Left = bar2->checkComp<TransformComp>()->GetPos().x - bar2->checkComp<TransformComp>()->GetScale().x / 2;
	float bar2Right = bar2->checkComp<TransformComp>()->GetPos().x + bar2->checkComp<TransformComp>()->GetScale().x / 2;
	float bar2Top = bar2->checkComp<TransformComp>()->GetPos().y + bar2->checkComp<TransformComp>()->GetScale().y / 2;
	float bar2Bottom = bar2->checkComp<TransformComp>()->GetPos().y - bar2->checkComp<TransformComp>()->GetScale().y / 2;

	float ballLeft = ball->checkComp<TransformComp>()->GetPos().x - ball->checkComp<TransformComp>()->GetScale().x / 2;
	float ballRight = ball->checkComp<TransformComp>()->GetPos().x + ball->checkComp<TransformComp>()->GetScale().x / 2;
	float ballTop = ball->checkComp<TransformComp>()->GetPos().y + ball->checkComp<TransformComp>()->GetScale().y / 2;
	float ballBottom = ball->checkComp<TransformComp>()->GetPos().y - ball->checkComp<TransformComp>()->GetScale().y / 2;
	if (bar1Left < ballRight && bar1Right > ballLeft &&
		bar1Top > ballBottom && bar1Bottom < ballTop
		||
		bar2Left < ballRight && bar2Right > ballLeft &&
		bar2Top > ballBottom && bar2Bottom < ballTop)
		ball->checkComp<BallComp>()->changeDir();


	ParticleSystem::getPtr()->Update(ball);

	//if (ParticleObject->checkComp<ParticleComp>()->GetLifetime() < 0)
	//{
	//	ParticleObject->checkComp<TransformComp>()->SetPos({ ball->checkComp<TransformComp>()->GetPos() });
	//	ParticleObject->checkComp<ParticleComp>()->SetParticleLifetime(1000);
	//}
	//if (ParticleObject2->checkComp<ParticleComp>()->GetLifetime() < 0)
	//{
	//	ParticleObject2->checkComp<TransformComp>()->SetPos({ ball->checkComp<TransformComp>()->GetPos() });
	//	ParticleObject2->checkComp<ParticleComp>()->SetParticleLifetime(1000);
	//}
	//if (ParticleObject3->checkComp<ParticleComp>()->GetLifetime() < 0)
	//{
	//	ParticleObject3->checkComp<TransformComp>()->SetPos({ ball->checkComp<TransformComp>()->GetPos() });
	//	ParticleObject3->checkComp<ParticleComp>()->SetParticleLifetime(1000);
	//}

	if (ball->checkComp<ScoreComp>()->Consecutive_points1 == 5 || ball->checkComp<ScoreComp>()->Consecutive_points2 == 5)
	{
		if (ball->checkComp<ScoreComp>()->Consecutive_points1 == 5)
		{
			std::cout << "Player1 WIN!" << std::endl;
			ScoreComp::highScore = ScoreComp::Consecutive_points1;
		}
		else if (ball->checkComp<ScoreComp>()->Consecutive_points2 == 5)
		{
			std::cout << "Player2 WIN!" << std::endl;
			ScoreComp::highScore = ScoreComp::Consecutive_points2;
		}
		Serializer::GetPtr()->SaveLevel("../Files/LevelSave.json");
		GSM::GameStateManager::GetGSMPtr()->ChangeLevel(nullptr);
	}
}

void Levels::GoalLevel::Exit()
{
	std::cout << "Goal level Exit:" << std::endl;
}
