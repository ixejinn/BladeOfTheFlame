#pragma once
#include "AEEngine.h"
#include "AEUtil.h"
#include "BaseLevel.h"
#include "../ComponentManager/GameObject.h"

namespace Levels
{
	class GoalLevel : public GSM::BaseLevel
	{
		GO* bar1;
		GO* bar2;
		GO* ball;
		GO* ParticleObject;
		GO* ParticleObject2;
		GO* ParticleObject3;

		void Init() override;
		void Update() override;
		void Exit() override;
	};
}
