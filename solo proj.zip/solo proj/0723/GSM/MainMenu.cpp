#include "MainMenu.h"
#include "GameStateManager.h"
#include "GoalLevel.h"

#include <iostream>

#include "../ComponentManager/GameObject.h"
#include "../Component/Engine/transformComp.h"

void Levels::MainLevel::Init()
{
	player = new GO;
	player->addComp(new TransformComp(player));

	counter = 0;
	std::cout << "Main level Init:" << std::endl;
}

void Levels::MainLevel::Update()
{
	std::cout << "Main level Update:" << std::endl;

	TransformComp* trs = dynamic_cast<TransformComp*>(player->checkComp<TransformComp>());

	if (trs)
	{
		trs->SetPos({ trs->GetPos().x + 1, trs->GetPos().y });

		if (counter & 10 == 0)
		{
			trs->SetRot(trs->GetRot() + 0.5f);
		}

		if (counter & 50 == 0)
		{
			trs->SetScale({trs->GetScale().x + 1.5f, trs->GetScale().y + 1.5f});
		}
	}

	//If goal was reached change level
	counter++;
	if (counter >= 100)
	{
		//Change to goal
		GSM::GameStateManager::GetGSMPtr()->ChangeLevel(new GoalLevel);
	}
}

void Levels::MainLevel::Exit()
{
	std::cout << "Main level Exit:" << std::endl;

}
