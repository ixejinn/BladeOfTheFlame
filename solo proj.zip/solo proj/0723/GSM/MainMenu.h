#pragma once
#include "BaseLevel.h"

class GO;

namespace Levels
{
	class MainLevel : public GSM::BaseLevel
	{
		int counter = 0;

		void Init() override;
		void Update() override;
		void Exit() override;

		GO* player;
	};
}