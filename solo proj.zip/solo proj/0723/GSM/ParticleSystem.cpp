#include "ParticleSystem.h"
#include "../Component/Engine/transformComp.h"
#include "../Component/Graphics/spriteComp.h"
#include "../Component/Engine/audioComp.h"

ParticleSystem* ParticleSystem::ptr = nullptr;

ParticleSystem::~ParticleSystem()
{
	for (auto& p : container)
	{
		for (auto& it : p.second)
		{
			delete it;
		}
		p.second.clear();
	}
	container.clear();
}

void ParticleSystem::Update(GO* owner)
{
	auto it = container.find(owner);
	for (GO* p : it->second)
	{
		if (p->checkComp<ParticleComp>()->GetLifetime() < 0)
		{
			p->checkComp<TransformComp>()->SetPos({ owner->checkComp<TransformComp>()->GetPos() });
			p->checkComp<RigidbodyComp>()->SetVeolcity({ -owner->checkComp<RigidbodyComp>()->getVelocity().x/5
				* p->checkComp<ParticleComp>()->GetInitialVeolcity().x,
				-owner->checkComp<RigidbodyComp>()->getVelocity().y/5 
				* p->checkComp<ParticleComp>()->GetInitialVeolcity().y });
			p->checkComp<ParticleComp>()->SetParticleLifetime(1000);
		}
	}
}

void ParticleSystem::SetParticleCount(int count, GO* go)
{
	container.emplace(go, NULL);
	auto it = container.find(go);
	for (GO* p : it->second)
	{
		delete p;
	}
	it->second.clear();

	for (int i = 0; i < count; i++)
	{
		GO* p = GOManager::getPtr()->addObj();
		TransformComp* particletransformcomp = static_cast<TransformComp*>(TransformComp::CreateTransformComp());
		SpriteComp* particlespritecomp = static_cast<SpriteComp*>(SpriteComp::CreateSpriteComp());
		AudioComp* particleaudiocomp = static_cast<AudioComp*>(AudioComp::CreateAudioComp());
		RigidbodyComp* particlerigidbodycomp = static_cast<RigidbodyComp*>(RigidbodyComp::CreateRigidbodyComp());
		ParticleComp* particle = static_cast<ParticleComp*>(ParticleComp::CreateParticleComp());

		p->addComp(particle);
		p->addComp(particletransformcomp);
		p->addComp(particlespritecomp);
		p->addComp(particleaudiocomp);
		p->addComp(particlerigidbodycomp);
		p->checkComp<TransformComp>()->SetPos(go->checkComp<TransformComp>()->GetPos());
		it->second.push_back(p);
	}
}

void ParticleSystem::SetInitialVelocity(const AEVec2& vel, GO* go)
{
	auto it = container.find(go);
	for (GO* p : it->second)
	{
		p->checkComp<ParticleComp>()->SetInitialVelocity(vel);
	}
}

void ParticleSystem::SetInitialScale(const AEVec2& scale, GO* go)
{
	auto it = container.find(go);
	for (GO* p : it->second)
	{
		p->checkComp<ParticleComp>()->SetInitialScale(scale);
	}
}

float ParticleSystem::GetLifetime(GO* go)
{
	auto it = container.find(go);
	float temp;
	for (GO* p : it->second)
	{
		temp = p->checkComp<ParticleComp>()->GetLifetime();
	}
	return temp;
}

void ParticleSystem::SetLifeTime(float time, GO* go)
{
	auto it = container.find(go);
	for (GO* p : it->second)
	{
		p->checkComp<ParticleComp>()->SetParticleLifetime(time);
	}
}

ParticleSystem* ParticleSystem::getPtr()
{
	if (ptr == nullptr)
		ptr = new ParticleSystem;
	return ptr;
}

void ParticleSystem::Delete()
{
	if (ptr != nullptr)
		delete ptr;
	ptr = nullptr;
}
