#pragma once
#include <list>
#include <map>
#include "../GameObjectManager/GameObjectManager.h"
#include "../Component/Engine/particleComp.h"
class ParticleSystem
{
	static ParticleSystem* ptr;
	std::map<GO*, std::list<GO*>> container;

	ParticleSystem() = default;
	ParticleSystem(const ParticleSystem&) = delete;
	const ParticleSystem& operator=(const ParticleSystem&) = delete;
	~ParticleSystem();
public:
	void Update(GO* owner);
	void SetParticleCount(int count, GO* go);
	void SetInitialVelocity(const AEVec2& vel, GO* go);
	void SetInitialScale(const AEVec2& scale, GO* go);
	float GetLifetime(GO* go);
	void SetLifeTime(float time, GO* go);
	static ParticleSystem* getPtr();
	static void Delete();
};