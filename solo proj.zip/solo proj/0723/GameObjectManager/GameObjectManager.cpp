#include "GameObjectManager.h"
#include "../ComponentManager/GameObject.h"
class GO;
GOManager* GOManager::ptr = nullptr;
GOManager::~GOManager()
{
	for (GO* obj : allGO)
	{
		delete obj;
	}
	allGO.clear();
}

GO* GOManager::addObj()
{
	GO* obj = new GO;

	if (obj)
		allGO.push_back(obj);
	return obj;
}

void GOManager::removeObj(GO* obj)
{
	if (std::find(allGO.begin(), allGO.end(), obj) != allGO.end())
	{
		delete obj;
		allGO.remove(obj);
	}
}

GO* GOManager::getLastObj()
{
	return allGO.back();
}

std::list<GO*> GOManager::allObj()
{
	return allGO;
}

GOManager* GOManager::getPtr()
{
	if (ptr == nullptr)
		ptr = new GOManager;
	return ptr;
}

void GOManager::Delete()
{
	if (ptr != nullptr)
		delete ptr;
	ptr = nullptr;
}
