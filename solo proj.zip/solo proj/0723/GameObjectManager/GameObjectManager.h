#pragma once
#include <list>
class GO;
class GOManager
{
	static GOManager* ptr;
	std::list<GO*> allGO;
	//singleton
	GOManager() = default;
	GOManager(const GOManager&) = delete;
	const GOManager& operator=(const GOManager&) = delete;
	~GOManager();
public:
	GO* addObj();
	void removeObj(GO* obj);
	GO* getLastObj();
	std::list<GO*> allObj();
	static GOManager* getPtr();
	static void Delete();
};