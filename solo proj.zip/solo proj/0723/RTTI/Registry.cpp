#include "Registry.h"
#include "../Component/Engine/transformComp.h"
#include "../Component/Logic/ScoreComp.h"
#include "../Component/Engine/audioComp.h"
#include "../Component/Engine/RigidbodyComp.h"
#include "../Component/Graphics/spriteComp.h"
#include "../Component/Logic/playerAComp.h"
#include "../Component/Logic/playerBComp.h"
#include "../Component/Logic/ball.h"
#include "../Component/Engine/particleComp.h"

Registry* Registry::ptr = nullptr;

Registry::Registry()
{
    //Register All the function
    rttiMap.insert({ TransformComp::TransformTypeName, &TransformComp::CreateTransformComp });
    rttiMap.insert({ScoreComp::ScoreTypeName, &ScoreComp::CreateScoreComp });
    rttiMap.insert({ RigidbodyComp::RigidbodyName, &RigidbodyComp::CreateRigidbodyComp });
    rttiMap.insert({ SpriteComp::SpriteTypeName, &SpriteComp::CreateSpriteComp});
    rttiMap.insert({ PlayerAComp::PlayerATypeName, &PlayerAComp::CreatePlayerAComp });
    rttiMap.insert({ PlayerBComp::PlayerBTypeName, &PlayerBComp::CreatePlayerBComp });
    rttiMap.insert({ AudioComp::AudioTypeName, &AudioComp::CreateAudioComp });
    rttiMap.insert({ BallComp::BallTypeName, &BallComp::CreateBallComp});
    rttiMap.insert({ ParticleComp::ParticleCompTypeName, &ParticleComp::CreateParticleComp });
}

Registry::~Registry()
{
}

Registry* Registry::GetPtr()
{
    if (ptr == nullptr)
    {
        ptr = new Registry;
    }
    return ptr;
}

void Registry::Delete()
{
    if (ptr != nullptr)
    {
        delete ptr;
    }

    ptr = nullptr;
}

BaseRTTI* Registry::FindAndCreate(const std::string& type)
{
    auto it = rttiMap.find(type);
    if (it == rttiMap.end())
    {
        return nullptr;
    }
    else
    {
        return it->second();
    }
}
