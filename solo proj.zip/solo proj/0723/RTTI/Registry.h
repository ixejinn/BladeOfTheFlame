#pragma once
#include <map>
#include <string>
#include "BaseRTTI.h"

class Registry
{
	// Singleton
	static Registry* ptr;
	Registry();		//Default constructor
	~Registry();	//Destructor

	//Prevent copies
	Registry(const Registry&) = delete;						//Registry a(b); Registry a = b;
	const Registry& operator=(const Registry&) = delete;	//a = b;

	// map with names/function_pointers
	std::map<std::string, BaseRTTI* (*)()> rttiMap;	//returnType functionpointer parameter
public:
	// Singleton interface
	static Registry* GetPtr();
	static void Delete();
	// Some interface to find inside me
	// TODO:
	BaseRTTI* FindAndCreate(const std::string& type);
};