#include "AudioResource.h"

void AudioResource::LoadData(const std::string filename)
{
	this->LoadAudioData(filename);
}

void AudioResource::UnLoadData()
{
	this->UnLoadAudioData();
}
