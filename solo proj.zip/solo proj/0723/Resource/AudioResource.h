#pragma once
#include <string>
#include "Resource.h"
#include "AEEngine.h"
#include "AEAudio.h"
class AudioResource : public Resource
{
	AEAudio audio;
	void LoadAudioData(const std::string filename)
	{
		audio = AEAudioLoadSound(filename.c_str());
		data = &audio;
		counter++;
	}
	void UnLoadAudioData()
	{
		AEAudioUnloadAudio(*static_cast<AEAudio*>(data));
		counter--;
	}
public:
	AudioResource() {};
	~AudioResource() {};
	void LoadData(const std::string filename) override;
	void UnLoadData() override;
};