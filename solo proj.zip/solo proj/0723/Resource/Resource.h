#pragma once
#include <string>
#include <map>

class Resource
{
protected:
	Resource() {};
public:
	//pure abstract class
	//	IF you inherit from me, you MUST override some fn
	bool persistent;
	int counter = 0;
	void* data = nullptr;
	//use static cast for this to become Texture*, Audio* ... whe needed
	//fn to return the data
	template <typename T>
	T* getData();

	//pure virtual fn to LOAD data
	virtual void LoadData(const std::string filename) = 0;
	//pure virtual fn to UNLOAD data
	virtual void UnLoadData() = 0;

	virtual ~Resource() {}	//Otherwise you would NOT be deleting the specialized classes
};

template<typename T>
inline T* Resource::getData()
{
	return data;
}
