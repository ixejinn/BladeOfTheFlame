#include "ResourceManager.h"
#include "Resource.h"
#include <map>
#include <string>
class Resource;
ResourceManager* ResourceManager::mInstance;
void ResourceManager::Unload(std::string name)
{
	auto it = rsc.find(name);
	if (it != rsc.end())
	{
		//DECREASE!!
		it->second->counter--;
		if (it->second->counter == 0)
		{
			it->second->UnLoadData();
			delete it->second;
			rsc.erase(name);
		}
		else
			return;
	}
	else
		return;
}

void ResourceManager::UnloadAll()
{
	for (auto it : rsc)
	{
		Unload(it.first);
	}
	return;
}

ResourceManager* ResourceManager::getResourceManagerInstance()
{
	if (mInstance == nullptr)
	{
		mInstance = new ResourceManager;
	}
	
	return mInstance;
}

fileExt ResourceManager::GetFileExt(std::string filename)
{
	std::string ext = filename.substr(filename.find_last_of(".") + 1);

	auto it = fileformat.find(ext);
	if (it != fileformat.end())
	{
		return it->second;
	}
	else
		return CANNOTFOUND;
}
