#pragma once
#include "Resource.h"
#include "TextureResource.h"
#include "AudioResource.h"
#include <map>
#include <string>

class TextureResource;

enum fileExt
{
	png,
	jpg,
	mp3,
	wav,
	CANNOTFOUND
};

class ResourceManager
{
	std::map<std::string, fileExt> fileformat
	{
		{"png", png},
		{"jpg", jpg},
		{"mp3", mp3},
		{"wav", wav}
	};

	//Singleton
	static ResourceManager* mInstance;
	ResourceManager() {};
	ResourceManager(const ResourceManager&) = delete;
	virtual ~ResourceManager() {};
	//map to hold names / resouce*
	std::map<std::string, Resource*> rsc;
	//Get<T>(name) fn that returns a T* to the data allocated in the resource with that name
		//IF the resource does not exist, load it
		//Load a resource depends on the EXTENSION of the file
			//switch statement, creating an approapiate constructor for the extension
	
public:
	static ResourceManager* getResourceManagerInstance();
	
	fileExt GetFileExt(std::string filename);
	template<typename T>
		T* Get(std::string name);
	//Unload(name) fn that removes 1 from the couter of the resource.
	//	IF the counter is 0, unload the resource, delete it, and remove from container
	void Unload(std::string name);
	//Fn to unload ALL resources== 
	void UnloadAll();
};

template<typename T>
inline T* ResourceManager::Get(std::string name)
{
	auto it = rsc.find(name);
	if (it != rsc.end())
	{
		//INCREASE COUNTER!!
		it->second->counter++;
		return static_cast<T*>(it->second);
	}
	else
	{
		//IF the resource does not exist, load it
		//Load a resource depends on the EXTENSION of the file
			//switch statement, creating an approapiate constructor for the extension TextureRes, MusicRes...
			//Add it to the map
		fileExt extension = GetFileExt(name);

		Resource* rs = nullptr;

		switch (extension)
		{
		case png:
		case jpg:
			//create an obj of type TextureResource in dynamic memory
			rs = new TextureResource;
			//call the load from that obj
			if (rs == nullptr)
				return nullptr;
			rs->LoadData(name);

			if (rs->data == nullptr)
				return nullptr;
			//insert it in the map
			rsc.insert({ name, rs });
			return static_cast<T*>(rs);
			break;

		case mp3:
		case wav:
			rs = new AudioResource;
			if (rs == nullptr)
				return nullptr;
			rs->LoadData(name);
			if (rs->data == nullptr)
				return nullptr;
			rsc.insert( {name, rs} );
			return  static_cast<T*>(rs);
			break;
		case CANNOTFOUND:
			break;
		}
	}

	return nullptr;
}