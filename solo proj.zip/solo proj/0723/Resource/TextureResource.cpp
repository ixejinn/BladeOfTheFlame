#include "TextureResource.h"

void TextureResource::LoadData(const std::string filename)
{
	this->LoadTextureData(filename);
}

void TextureResource::UnLoadData()
{
	this->UnLoadTextureData();
}
