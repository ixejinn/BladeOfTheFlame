#pragma once
#include <string>
#include "Resource.h"
#include "AEEngine.h"
#include "AEGraphics.h"
class TextureResource : public Resource
{
	void LoadTextureData(const std::string filename)
	{
		data = AEGfxTextureLoad(filename.c_str());
		counter++;
	}
	void UnLoadTextureData()
	{
		AEGfxTextureUnload(static_cast<AEGfxTexture*>(data));
		counter--;
	}
public:
	TextureResource() {};
	~TextureResource() {};
	void LoadData(const std::string filename) override;
	void UnLoadData() override;
};