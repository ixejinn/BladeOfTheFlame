#include "Serializer.h"
#include"json.hpp"
#include"../ComponentManager/BaseComponent.h"
#include <fstream>
#include <iostream>

//Arch dependant
#include "../GameObjectManager/GameObjectManager.h"
#include "../ComponentManager/BaseComponent.h"
#include "../ComponentManager/GameObject.h"
#include "../RTTI/Registry.h"

//using json = nlohmann::json;						//Map. Orders alphebetically on pushback and insert
using json = nlohmann::ordered_json;		//Map. Keeps the order the variables were declared in
Serializer* Serializer::ptr = nullptr;
Serializer* Serializer::GetPtr()
{
	if (ptr == nullptr)
		ptr = new Serializer;
	return ptr;
}

void Serializer::Delete()
{
	if (ptr != nullptr)
		delete ptr;
	ptr = nullptr;
}

void Serializer::LoadLevel(const std::string& s)
{
	//open file
	std::fstream file;
	file.open(s, std::fstream::in);

	//Check the file is valid
	if (!file.is_open())
	{
		std::cout << "file does not open" << std::endl;
		return;
	}
	json Alldata;
	file >> Alldata;		//The json has all the file data

	for (auto& item : Alldata)	//Depending on how you saved, you look for some values or others
	{
		//Create an object IF this is an obj
		auto obj	 = item.find("Object");	//Iterator
		if (obj != item.end())	//It was found
		{
			//Create the go
			GO* go = GOManager::getPtr()->addObj();

			//Find the component section
			auto cmp = item.find("Components");
			if (cmp == item.end()	)	//NOT Found
				continue;
			//Iterate on the json on cmp for each component, add it
			for (auto& c : *cmp)
			{
				auto t = c.find("Type");
				if (t == c.end())
					continue;

				std::string typeName = t.value();		//convert to string

				//Look in the registry for this type and create it
				BaseRTTI* p = Registry::GetPtr()->FindAndCreate(typeName);

				if (p != nullptr)
					p->LoadFromJson(c);
			}
		}
	}
}

void Serializer::SaveLevel(const std::string& s)
{
	json Alldata;

	//Counter instead of name as I do not have one
	int i = 0;

	//iterate on each go
	for (GO* go : GOManager::getPtr()->allObj())
	{
		json obj;
		obj["Object"] = i++;

		json components;
		//iterate on each component
		for (auto& c : go->AllComp())
		{
			BaseComponent* comp = c;
			components.push_back(comp->SaveToJson());	//Check in a moment
		}

		obj["Components"] = components;
		
		Alldata.push_back(obj);
	}

	//Open file
	std::fstream file;
	file.open(s, std::fstream::out);	//Open as write mode. Create it if it does not exist!

	if (!file.is_open())
	{
		std::cout << "file does not open" << std::endl;
		return;
	}
	//file << Alldata;						//All in 1 line
	file << std::setw(2) << Alldata;	//Separates in lines and each section

	file.close();
}
