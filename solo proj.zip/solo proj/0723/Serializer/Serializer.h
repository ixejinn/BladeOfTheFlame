#pragma once
#include <string>
class Serializer
{
	//Singleton
	static Serializer* ptr;
	Serializer() = default;
	~Serializer() {};
	Serializer(const Serializer&) = delete;
	const Serializer& operator=(const Serializer&) = delete;
public:
	static Serializer* GetPtr();
	static void Delete();

	void LoadLevel(const std::string& s);

	void SaveLevel(const std::string& s);
};