#include <string>
#include <iostream>
#include <crtdbg.h> // To check for memory leaks
#include "AEEngine.h"

#include"GSM/GameStateManager.h"
#include"GSM/MainMenu.h"
#include "Resource/ResourceManager.h"
#include "Resource/Resource.h"
#include "RTTI/Registry.h"
#include "Serializer/Serializer.h"
#include "GameObjectManager/GameObjectManager.h"
#include "GSM/GoalLevel.h"

// ---------------------------------------------------------------------------
// main

std::string Texture_filename = "../Extern/Assets/abc.png";


int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR    lpCmdLine,
	_In_ int       nCmdShow)
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	int gGameRunning = 1;

	// Initialization of your own variables go here

	// Using custom window procedure
	AESysInit(hInstance, nCmdShow, 1600, 900, 1, 60, true, NULL);

	// Changing the window title
	AESysSetWindowTitle("Solo_project");

	GSM::GameStateManager* gsm = GSM::GameStateManager::GetGSMPtr();
	Serializer* mSerializer = Serializer::GetPtr();

	//Test RTTI
	Registry* RTTIptr = Registry::GetPtr();

	//Find the function, call the function and store that BaseRTTI*
	//BaseRTTI* transfp = RTTIptr->FindAndCreate("TransformComp");
	//BaseRTTI* scorep = RTTIptr->FindAndCreate("ScoreComp");

	//p->Load("AAA");	//This should call to TransformComp::Load(string)
	//delete transfp;
	//delete scorep;

	//Test for each comp
	//Test INVALID name on the find

	// reset the system modules
	AESysReset();

	gsm->ChangeLevel(new Levels::MainLevel);

	//Load files
	/*std::string image = "../../Extern/Assets/abc.png";
	std::string imageHARD = "C:/Users/BCA/Desktop/0723/Extern/Assets/abc.png";
	std::string music = "../../Extern/Assets/abc.mp3";
	std::string invalid = "../../Extern/Assets/abc.asuhd";
	std::string image2 = image;
	std::string image3 = "../../Extern/Assets/abc2.png";*/

	//TextureResource* tr = ResourceManager::getResourceManagerInstance()->Get<TextureResource>(image);	//Load failed. Data is null!
	//TextureResource* trH = ResourceManager::getResourceManagerInstance()->Get<TextureResource>(imageHARD);	//Load failed. Data is null!
	//AudioResource* ar = ResourceManager::getResourceManagerInstance()->Get<AudioResource>(music);	//Load failed (fmodaudio was nullptr)
	////ar�� �ѹ� �� �־��ٶ��� ��� �ذ��ϱ�
	//Resource* ir = ResourceManager::getResourceManagerInstance()->Get<Resource>(invalid);			//Sjhould be nullptr
	//TextureResource* tr2 = ResourceManager::getResourceManagerInstance()->Get<TextureResource>(image2);		//Correct output. BUT Counter did not increase!
	//TextureResource* ir2 = ResourceManager::getResourceManagerInstance()->Get<TextureResource>(image3);		//Loaded an invalid texture. Should be nullptr


	//ResourceManager::getResourceManagerInstance()->Unload(image);	//Load failed. Data is null!
	//ResourceManager::getResourceManagerInstance()->Unload(music);	//Load failed (fmodaudio was nullptr)
	//ResourceManager::getResourceManagerInstance()->Unload(invalid);			//Sjhould be nullptr
	//ResourceManager::getResourceManagerInstance()->Unload(image2);		//Correct output. BUT Counter did not increase!
	//ResourceManager::getResourceManagerInstance()->Unload(image3);		//Loaded an invalid texture. Should be nullptr

	//Check the map is empty!
	//Check for mem leaks!

	AEGfxSetBackgroundColor(0, 0, 0);
	// Game Loop
	while (gsm->ShouldExit() == false)
	{
		// Informing the system about the loop's start
		AESysFrameStart();

		// Your own rendering logic goes here
		gsm->Update();

		// Informing the system about the loop's end
		AESysFrameEnd();

		// check if forcing the application to quit
		if (AEInputCheckTriggered(AEVK_ESCAPE) || 0 == AESysDoesWindowExist())
			gsm->ChangeLevel(new Levels::GoalLevel);
	}
	gsm->DeleteGSM();
	Registry::Delete();
	GOManager::Delete();

	// free the system
	AESysExit();
}